package com.savindupasintha.spring.boot.full.course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFullCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFullCourseApplication.class, args);
	}

}
