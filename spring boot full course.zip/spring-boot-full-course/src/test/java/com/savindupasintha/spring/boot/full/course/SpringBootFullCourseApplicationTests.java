package com.savindupasintha.spring.boot.full.course;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFullCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
